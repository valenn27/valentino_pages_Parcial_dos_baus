package modelo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Filter;
import java.io.*;
import java.util.function.Consumer;

public class Zoologico<T> {
    List<T> inventario = new ArrayList<>();


    public void agregar(T t) {
        if(t == null) {
            throw new NullPointerException("elemento invalido");
        }

        inventario.add(t);
    }

    public T obtenerIndice(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            throw new IndexOutOfBoundsException("indice fuera de rango");
        }
        return inventario.get(indice);
    }

    public void eliminar(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            throw new IndexOutOfBoundsException("indice fuera de rango");
        }
        inventario.remove(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T e : inventario) {
            if(criterio.test(e)) {
                aux.add(e);
            }
        }
        return aux;
    }


    public void ordenar(Comparator<? super T> comparator) {
        if (comparator == null) {
            inventario.sort(null);
        } else {
            inventario.sort(comparator);
        }
    }


    public void paraCadaElemento(Consumer<? super T> accion) {
    if (accion == null) {
        throw new NullPointerException("accion invalida");
    }
    for (T elemento : inventario) {
        accion.accept(elemento);
    }
}
    
    

    public void guardarAnimalesBinario(String path) {
        serializar(path);
    }

    public void CargarAnimalesBinario(String path) {
        deserializar(path);
    }


    public void guardarAnimalesCSV(String path) {
        guardarEnCSV(path);
    }

    public void CargarAnimalesCSV(String path, CSVdeserializar<Animal> deserializador) {
        List<Animal> animalesCargados = cargarDesdeCSV(path, deserializador);
        inventario.addAll((List<T>) animalesCargados); 
    }



    private void serializar(String path) {
        try (FileOutputStream archivo = new FileOutputStream(path);
             ObjectOutputStream salida = new ObjectOutputStream(archivo)) {

            salida.writeObject(inventario);
            System.out.println("serializable guardado con exito");
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }



    private void deserializar(String path) {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            
            inventario = (List<T>) entrada.readObject();
            
            System.out.println("Lista deserializada desde: " + path);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    private void  guardarEnCSV(String path) {
        File archivo = new File(path);

        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
                System.out.println("archivo CSV creado con exito");
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
                for (T elemento : inventario) {
                    if(elemento instanceof Animal a) {
                        bw.write(a.toCSV() + "\n");
                    }
                   
                }
                System.out.println("inventario guardado en CSV");
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
    }


    private List<Animal> cargarDesdeCSV(String path, CSVdeserializar<Animal> deserializador) {
        List<Animal> ToReturn = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                Animal a = deserializador.fromCSV(linea);
                if (a != null) {
                    ToReturn.add(a);
                }
            }

        } catch (IOException ex) {
            ex.getMessage();
        }
        return ToReturn;
    }

}
