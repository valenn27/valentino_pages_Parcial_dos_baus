package modelo;

public interface CSVdeserializar<T extends CSVSerializable> {
    T fromCSV(String csvLine);
}
