package modelo;

import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion tipoAlimentacion;


    public Animal(int id, String nombre, String especie, TipoAlimentacion tipoAlimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.tipoAlimentacion = tipoAlimentacion;
    }

    public TipoAlimentacion getTipoAlimentacion() {
        return tipoAlimentacion;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(id, o.id);
    }



    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + tipoAlimentacion;
    }


    public static Animal fromCSV(String csvLinea) {
        String[] data = csvLinea.split(",");
        if (data.length != 4) {
            throw new IllegalArgumentException("linea csv invalida: " + csvLinea);
        }
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        String especie = data[2];
        TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
        return new Animal(id, nombre, especie, alimentacion);
    }


    @Override
    public String toString() {
        return "Animal{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", especie='" + especie + '\'' +
                ", tipoAlimentacion=" + tipoAlimentacion +
                '}';
    }
}
