package ParcialDos;


import modelo.Animal;
import modelo.TipoAlimentacion;
import modelo.Zoologico;

public class Parcial_dos_baus {
    public static void main(String[] args) {
        try {

            Zoologico<Animal> zoologico = new Zoologico<>();

            zoologico.agregar(new Animal(1, "Leon", "Panthera leo",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(2, "Elefante", "Loxodonta",
                    TipoAlimentacion.HERBIVORO));
            zoologico.agregar(new Animal(3, "Oso", "Ursus arctos",
                    TipoAlimentacion.OMNIVORO));
            zoologico.agregar(new Animal(4, "Zorro", "Vulpes vulpes",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(5, "Gorila", "Gorilla gorilla",
                    TipoAlimentacion.OMNIVORO));


            System.out.println("Inventario de animales:");
            zoologico.paraCadaElemento(animal -> System.out.println(animal));


            System.out.println("\nAnimales CARNIVOROS:");
            zoologico.filtrar(a -> ((Animal) a).getTipoAlimentacion() == TipoAlimentacion.CARNIVORO)
                    .forEach(animal -> System.out.println(animal));



            System.out.println("\nAnimales cuyo nombre contiene 'Leon':");
            zoologico.filtrar(a -> ((Animal) a).getNombre().equals("Leon"))
                    .forEach(animal -> System.out.println(animal));



            System.out.println("\nAnimales ordenados de manera natural (por id):");
            zoologico.ordenar(null);
            zoologico.paraCadaElemento(animal -> System.out.println(animal));

            // Ordenar animales por nombre utilizando un Comparator
            System.out.println("\nAnimales ordenados por nombre:");
            zoologico.ordenar((a1, a2) -> a1.getNombre().compareTo(a2.getNombre()));
            zoologico.paraCadaElemento(animal -> System.out.println(animal));


            // Guardar el zoológico en un archivo binario
            zoologico.guardarAnimalesBinario("src/main/java/data/animales.dat");

            // Cargar el zoológico desde el archivo binario
               Zoologico<Animal> zoologicoCargado = new Zoologico<>();
            zoologicoCargado.CargarAnimalesBinario("src/main/java/data/animales.dat");
            System.out.println("\nAnimales cargados desde archivo binario:");
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));


            // Guardar el zoológico en un archivo CSV
             zoologico.guardarAnimalesCSV("src/main/java/data/animales.csv");


             // Cargar el zoológico desde el archivo CSV
             zoologicoCargado.CargarAnimalesCSV("src/main/java/data/animales.csv", linea ->
                    Animal.fromCSV(linea));
            System.out.println("\nAnimales cargados desde archivo CSV:");
             zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));


        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
